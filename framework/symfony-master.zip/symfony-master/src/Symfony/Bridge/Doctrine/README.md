Doctrine Bridge
===============

Provides integration for [Doctrine](http://www.doctrine-project.org/) with
various Symfony components.

Resources
---------

You can run the unit tests with the following command:

    $ cd path/to/Symfony/Bridge/Doctrine/
    $ composer install
    $ phpunit
